//
//  ViewController.m
//  RAC_链式编程
//
//  Created by LC on 2017/3/7.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import "ViewController.h"
#import "NSObject+CaculatorMaker.h"
#import "CaculatorMaker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    int iResult = [NSObject makeCaculators:^(CaculatorMaker *make) {
        
        make.add(1).add(2).add(3).divide(2);
        
    }];
    
    NSLog(@" 1===== %d",iResult);
    
    CaculatorMaker *maker = [[CaculatorMaker alloc]init];
    
    NSInteger reslut =
    [[[maker caculator:^int(int result) {
        result += 2;
        result *= 5;
        return result;
        
    }] equle:^BOOL(int result) {
        
        return result = 10;
        
    }] isEqule];
    
    
    NSLog(@" 2===== %ld",(long)reslut);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
