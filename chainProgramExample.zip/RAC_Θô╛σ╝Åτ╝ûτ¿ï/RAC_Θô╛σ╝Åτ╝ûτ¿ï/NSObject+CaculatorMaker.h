//
//  NSObject+CaculatorMaker.h
//  RAC_链式编程
//
//  Created by LC on 2017/3/7.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CaculatorMaker;

@interface NSObject (CaculatorMaker)

//计算

+ (int)makeCaculators:(void(^)(CaculatorMaker *make))caculatorMaker;

@end
