//
//  CaculatorMaker.m
//  RAC_链式编程
//
//  Created by LC on 2017/3/7.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import "CaculatorMaker.h"

@implementation CaculatorMaker

- (CaculatorMaker *(^)(int))add {
    
    return ^(int value)
    
    {
        
        _iResult += value;
        
        return self;
        
    };
    
}

//减法

- (CaculatorMaker *(^)(int))sub {
    return ^(int value)
    
    {
        
        _iResult -= value;
        
        return self;
        
    };
}


//乘法

- (CaculatorMaker *(^)(int))muilt {
    return ^(int value) {
        
        _iResult *= value;
        
        return self;
        
    };
}


//除法

- (CaculatorMaker *(^)(int))divide {
    return ^(int value) {
        
        _iResult /= value;
        
        return self;
        
    };
}


- (CaculatorMaker *)caculator:(int(^)(int result))operation {
    if (operation) {
        self.iResult = operation(self.iResult);
    }
   return self;
    
}

- (CaculatorMaker *)equle:(BOOL(^)(int result))operation {
    if (operation) {
        self.isEqule = operation(self.iResult);
    }
    return self;
}

@end
