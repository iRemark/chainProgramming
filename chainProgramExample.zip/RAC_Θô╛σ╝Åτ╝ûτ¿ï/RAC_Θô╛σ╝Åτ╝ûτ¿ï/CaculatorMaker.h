//
//  CaculatorMaker.h
//  RAC_链式编程
//
//  Created by LC on 2017/3/7.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CaculatorMaker : NSObject
@property (nonatomic, assign) int iResult;
@property (nonatomic, assign) BOOL isEqule;

//加法

- (CaculatorMaker *(^)(int))add;


//减法

- (CaculatorMaker *(^)(int))sub;


//乘法

- (CaculatorMaker *(^)(int))muilt;


//除法

- (CaculatorMaker *(^)(int))divide;

- (CaculatorMaker *)caculator:(int(^)(int result))operation;
- (CaculatorMaker *)equle:(BOOL(^)(int result))operation;

@end
