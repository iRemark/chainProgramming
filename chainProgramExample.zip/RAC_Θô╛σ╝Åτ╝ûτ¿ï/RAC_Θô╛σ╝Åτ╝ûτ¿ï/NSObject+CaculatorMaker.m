//
//  NSObject+CaculatorMaker.m
//  RAC_链式编程
//
//  Created by LC on 2017/3/7.
//  Copyright © 2017年 Lc. All rights reserved.
//

#import "NSObject+CaculatorMaker.h"
#import "CaculatorMaker.h"

@implementation NSObject (CaculatorMaker)
//计算

+ (int)makeCaculators:(void(^)(CaculatorMaker *make))block

{
    
    CaculatorMaker *mgr = [[CaculatorMaker alloc] init];
    
    block(mgr);
    
    return mgr.iResult;
    
}



@end
