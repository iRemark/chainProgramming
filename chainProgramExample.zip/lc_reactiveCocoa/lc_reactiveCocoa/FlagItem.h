//
//  FlagItem.h
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/22.
//  Copyright © 2017年 prd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FlagItem : NSObject

+ (FlagItem *)flagWithDict:(NSDictionary *)dict;


@end
