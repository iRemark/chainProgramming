//
//  ViewController.m
//  自学reactivecocoa
//
//  Created by admin on 15/9/11.
//  Copyright (c) 2015年 大强哥. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initData];
    [self initUI];
    
    
}
- (void)initData {
    [self.dataArr addObject:@"SummaryController"];
    [self.dataArr addObject:@"ArrDicModelController"];
    [self.dataArr addObject:@"SubscribeViewController"];
    [self.dataArr addObject:@"LoginViewController"];
    [self.dataArr addObject:@"LoginViewController2"];
    [self.dataArr addObject:@"NetViewController"];
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (self.dataArr.count > indexPath.row) {
        Class cls = NSClassFromString(self.dataArr[indexPath.row]);
        UIViewController *vc = [[cls alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
