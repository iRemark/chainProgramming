//
//  NetViewController.m
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/24.
//  Copyright © 2017年 prd. All rights reserved.
//

#import "NetViewController.h"

@interface NetViewController ()

@property (strong, nonatomic) UITextField *usernameTextField;
@property (strong, nonatomic) UITextField *passwordTextField;
@property (strong, nonatomic) UITextField *comfirmTextField;

@property (strong, nonatomic) UIButton *registerButton;
@property (strong, nonatomic) UIView *myView;

@end

@implementation NetViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    CGFloat y = 70;
    self.usernameTextField = [[UITextField alloc]init];
    self.usernameTextField.frame = CGRectMake(10, y, 200, 40);
    self.usernameTextField.layer.cornerRadius = 5;
    self.usernameTextField.layer.borderWidth  = 1.0;
    [self.view addSubview:self.usernameTextField];
    
    
    y+=50;
    self.passwordTextField = [[UITextField alloc]init];
    self.passwordTextField.frame = CGRectMake(10, y, 200, 40);
    self.passwordTextField.layer.cornerRadius = 5;
    self.passwordTextField.layer.borderWidth  = 1.0;
    [self.view addSubview:self.passwordTextField];
    
    y+=50;
    self.comfirmTextField = [[UITextField alloc]init];
    self.comfirmTextField.frame = CGRectMake(10, y, 200, 40);
    self.comfirmTextField.layer.cornerRadius = 5;
    self.comfirmTextField.layer.borderWidth  = 1.0;
    [self.view addSubview:self.comfirmTextField];
    
    self.registerButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.registerButton.frame = CGRectMake(300, 70, 100, 100);
    self.registerButton.backgroundColor = [UIColor redColor];
    [self.registerButton setTitle:@"register" forState:UIControlStateNormal];
    [self.registerButton setTitle:@"disableLogin" forState:UIControlStateDisabled];
    [self.view addSubview:self.registerButton];
    
    y+=50;
    self.myView = [[UIView alloc]initWithFrame:CGRectMake(10, y, 350, 100)];
    self.myView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:self.myView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)lc_islegal {
    // 设置用户名是否合法的信号
    // map用于改变信号返回的值，在信号中判断后，返回bool值
    RACSignal *usernameSignal = [self.usernameTextField.rac_textSignal map:^id(NSString *usernameText) {
        
        NSUInteger length = usernameText.length;
        
        if (length >= 1 && length <= 16) {
            return @(YES);
        }
        return @(NO);
    }];
    
    RACSignal *passwordSignal = [self.usernameTextField.rac_textSignal map:^id(NSString *usernameText) {
        
        NSUInteger length = usernameText.length;
        
        if (length >= 1 && length <= 16) {
            return @(YES);
        }
        return @(NO);
    }];
    
    // 设置确认密码合法的信号
    // 因为确认密码的文本要和密码的文本有关联，无论确认密码修改还是密码修改，都需要及时判断，所以需要绑定两个信号量
    RACSignal *comfirmSignal = [RACSignal combineLatest:@[self.passwordTextField.rac_textSignal, self.comfirmTextField.rac_textSignal] reduce:^id(NSString *passwordText, NSString *comfirmText){
        
        NSUInteger length = comfirmText.length;
        
        if (length >= 1 && [comfirmText isEqualToString:passwordText]) {
            return @(YES);
        }
        return @(NO);
    }];
    
    // 绑定用户名、密码、确认密码判断结果的三个信号量，如果三个都为真，则按钮可用
    RAC(self.registerButton, enabled) = [RACSignal combineLatest:@[usernameSignal, passwordSignal, comfirmSignal] reduce:^(NSNumber *isUsernameCorrect, NSNumber *isPasswordCorrect, NSNumber *isComfirmCorrect){
        
        return @(isUsernameCorrect.boolValue && isPasswordCorrect.boolValue && isComfirmCorrect.boolValue);
    }];
}


- (void)lc_search {
    UITextField *searchTextField = [[UITextField alloc]init];
    
    @weakify(self);
    [[[[[searchTextField.rac_textSignal
         // 先将不合法的搜索词过滤掉（返回的bool值决定了signal是否继续向下传递）
         filter:^BOOL(NSString *searchKeyword) {
             
             return @(searchKeyword.length);
         }]
        // 因为没必要每次一输入便进行网络请求，所以0.5s之后，才进行搜索。(throttle是在规定时间后，信号继续向下传递)
        throttle:0.5]
       // 网络请求将会返回signal，所以直接使用flattenMap来映射，而不必用map
       flattenMap:^RACStream *(NSString *searchKeyword) {
           
           @strongify(self);
           // 发起网络请求
//           return [self searchWithKeyword:searchKeyword];
           return [RACSignal empty];
       }]
      // 回到主线程，因为在signal订阅中可能更新界面
      deliverOnMainThread]
     // 订阅网络请求返回的信号
     subscribeNext:^(id x) {
         
         NSLog(@"%@", x);
     }];

}


- (void)blockInsert {
    // 假设发起两个请求
    // request1与request2是自定义方法，会返回两个信号
    RACSignal *signal1 = [self request1];
    RACSignal *signal2 = [self request2];
    
    [[signal1 concat:signal2] subscribeNext:^(id x) {
        
        NSLog(@"%@", x);
    }];
}
- (RACSignal *)request1 {
    
    return [RACSignal createSignal:^RACDisposable *(id subscriber) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [subscriber sendNext:@"请求1完成"];
            [subscriber sendCompleted];
        });
        
        return nil;
    }];
}

- (RACSignal *)request2 {
    
    return [RACSignal createSignal:^RACDisposable *(id subscriber) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [subscriber sendNext:@"请求1完成"];
            [subscriber sendCompleted];
        });
        
        return nil;
    }];
}


/** 这个需求可以用之前的 combineLatest 方法，也可以用 merge 方法。这两个方法都是要在全部信号都 sendNext 以后才会触发最终结果的。 **/
- (void)merge {
//    [[signal1 merge:signal2] subscribeNext:^(id x) {
//        
//        NSLog(@"%@", x);
//    }];
}

@end
