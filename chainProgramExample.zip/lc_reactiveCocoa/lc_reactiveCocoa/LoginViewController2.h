//
//  LoginViewController2.h
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/24.
//  Copyright © 2017年 prd. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^changeMyViewBackgroundColor)(UIView *);
@interface LoginViewController2 : UIViewController

- (void)changeMyViewBackgroundColor:(changeMyViewBackgroundColor)changeMyViewBackgroundColor;
@end
