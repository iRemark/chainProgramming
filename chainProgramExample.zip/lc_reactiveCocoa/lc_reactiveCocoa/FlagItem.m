//
//  FlagItem.m
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/22.
//  Copyright © 2017年 prd. All rights reserved.
//

#import "FlagItem.h"

@implementation FlagItem
+ (FlagItem *)flagWithDict:(NSDictionary *)dict {
    FlagItem *fmodel = [[FlagItem alloc]init];
    [fmodel setValuesForKeysWithDictionary:dict];
    return fmodel;
}
@end
