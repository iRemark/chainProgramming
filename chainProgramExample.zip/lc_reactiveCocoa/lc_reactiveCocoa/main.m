//
//  main.m
//  lc_reactiveCocoa
//
//  Created by prd on 2017/3/22.
//  Copyright © 2017年 prd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
