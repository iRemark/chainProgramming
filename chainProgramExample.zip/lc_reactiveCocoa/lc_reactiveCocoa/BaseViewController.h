//
//  BaseViewController.h
//  lc_reactiveCocoa
//
//  Created by LC on 2017/3/23.
//  Copyright © 2017年 prd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArr;

- (void)initData;
- (void)initUI;

@end
